# Blue Whales

A Pen created on CodePen.io. Original URL: [https://codepen.io/Trey-Dog/pen/MWZwgWO](https://codepen.io/Trey-Dog/pen/MWZwgWO).

